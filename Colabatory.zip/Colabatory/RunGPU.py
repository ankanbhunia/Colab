import time
import easygui
from selenium import webdriver
import pickle
import time

def save_cookie(driver, path):
    with open(path, 'wb') as filehandler:
        pickle.dump(driver.get_cookies(), filehandler)

def load_cookie(driver, path):
     with open(path, 'rb') as cookiesfile:
         cookies = pickle.load(cookiesfile)
         for cookie in cookies:
             driver.add_cookie(cookie)
import socket
def is_connected():
  try:
    # see if we can resolve the host name -- tells us if there is
    # a DNS listening
    host = socket.gethostbyname("www.google.com")
    # connect to the host -- tells us if the host is actually
    # reachable
    s = socket.create_connection((host, 80), 2)
    return True
  except:
     pass
  return False
def refresh(driver):
    if is_connected():
        driver.get('https://colab.research.google.com/drive/1496btMTwDNyHfd7hm2zz47mP0CcDJq3t')
    else:
        print ('No internet connection')
def Whandle(driver):
    wins = driver.window_handles
    if len(wins)>1:
        for i in wins:
            driver.switch_to.window(i)
            if not (('colab' in driver.current_url) or ('localtunnel' in driver.current_url) or ('ngrok' in driver.current_url)):
                driver.close()
    driver.switch_to.window(driver.window_handles[0])   
GPU = easygui.choicebox(msg = 'Select one GPU ',title='ColabGPU' ,choices = ['GPU1','GPU2','GPU3'])
if GPU == 'GPU1':
    cookies_path = 'pickel_file1'
elif GPU == 'GPU2':
    cookies_path = 'pickel_file2'
elif GPU == 'GPU3':
    cookies_path = 'pickel_file3'
Ndriver = webdriver.Firefox()
Ndriver.get('http://google.com/')
load_cookie(Ndriver, cookies_path)
Ndriver.get('https://colab.research.google.com/drive/1496btMTwDNyHfd7hm2zz47mP0CcDJq3t')
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
Foptions = Options()
Foptions.add_argument('--headless')
driver = webdriver.Firefox(firefox_options = Foptions)
driver.get('http://google.com/')
load_cookie(driver, cookies_path)
driver.get('https://colab.research.google.com/drive/1496btMTwDNyHfd7hm2zz47mP0CcDJq3t')
while True:
    Whandle(driver)
    try:
        try:
            okk = driver.find_elements('id','ok')
            try:
            
                if len(okk)>0:
                    for i in okk:
                        i.click()
            except:
                print('error')
                print (len(driver.find_elements_by_tag_name('iframe')))
                driver.switch_to_default_content()
                
            try:
                connect_button = driver.find_element_by_id('connect')
            except:
                print ('Not Found Error: Trying to solve ')
                driver.get_screenshot_as_file(str(int(time.time()))+'.png')
                Whandle(driver)
                time.sleep(20)
                refresh(driver)
                Whandle(driver)
                time.sleep(20)
                
            if not connect_button.text == 'CONNECTED':
                ti = time.localtime()[3:5]
                print (str(ti[0]) + ':'+str(ti[1]) + ' : Trying to reconnect')
                try:
                    connect_button.click()
                except:
                    print ('Not Clickable Error: Trying to solve')
                    driver.get_screenshot_as_file(str(int(time.time()))+'.png')
                    Whandle(driver)
                    time.sleep(20)
                    refresh(driver)
                
            
            
            Whandle(driver)   
            time.sleep(60)
            Whandle(driver)
            driver.save_screenshot('log.png')

        

        except KeyboardInterrupt:
            
            break
    except Exception as e:
        print (e)
        time.sleep(2)