import time
import easygui
from selenium import webdriver
import pickle
import time

def save_cookie(driver, path):
    with open(path, 'wb') as filehandler:
        pickle.dump(driver.get_cookies(), filehandler)

def load_cookie(driver, path):
     with open(path, 'rb') as cookiesfile:
         cookies = pickle.load(cookiesfile)
         for cookie in cookies:
             driver.add_cookie(cookie)
            
GPU = easygui.choicebox(msg = 'Select one GPU ',title='ColabGPU' ,choices = ['GPU1','GPU2','GPU3'])
if GPU == 'GPU1':
    cookies_path = 'pickel_file1'
elif GPU == 'GPU2':
    cookies_path = 'pickel_file2'
elif GPU == 'GPU3':
    cookies_path = 'pickel_file3'

Ndriver = webdriver.Firefox()
Ndriver.get('http://google.com/')
load_cookie(Ndriver, cookies_path)
Ndriver.get('https://colab.research.google.com/drive/1496btMTwDNyHfd7hm2zz47mP0CcDJq3t')